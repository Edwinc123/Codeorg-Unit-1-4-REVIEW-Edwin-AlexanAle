var userName;
var subject;
var States;
//on the event the the user writes their name it will apear in the finalAnswer
onEvent("entername", "input", function( ) {
  userName = getText("entername");
  setProperty("finalAnswer", "text", userName);
  updateScreen();
});

//when the dropdown is changed then it will run the function
onEvent("countrydropDown", "change", function( ) {
  States = getText("countrydropDown");
  updateScreen();
});

//on the event that the sunjectdropdown is changed it will run the function  
onEvent("subjectdropDown", "change", function( ) {
  subject = getText("subjectdropDown");
  updateScreen();
});

//updates the screen 
function updateScreen() {
  if (subject == "Math" && States == "California") {
    setText("finalAnswer", userName + " We recommend that you should go to Standford University. Stanford University is a private institution that was founded in 1885. It has a total undergraduate enrollment of 8,049 (fall 2022), its setting is suburban, and the campus size is 8,180 acres. It utilizes a quarter-based academic calendar. Stanford University's ranking in the 2024 edition of Best Colleges is National Universities, #3. Its tuition and fees are $62,484.");
  } else if ((subject == "Business" && States == "Michigan")) {
    setText("finalAnswer", userName + " We recommend that you should go to the University of Michigan. University of Michigan—Ann Arbor is a public institution that was founded in 1817. It has a total undergraduate enrollment of 32,695 (fall 2022), its setting is city, and the campus size is 3,207 acres. It utilizes a trimester-based academic calendar. University of Michigan—Ann Arbor's ranking in the 2024 edition of Best Colleges is National Universities, #21. Its in-state tuition and fees are $17,786; out-of-state tuition and fees are $57,273." );
  } else if ((subject == "technology" && States == "Massachusetts")) {
    setText("finalAnswer", userName + " We recommend that you should go to the Massachusetts Institute of Technology. Massachusetts Institute of Technology is a private institution that was founded in 1861. It has a total undergraduate enrollment of 4,657 (fall 2022), its setting is urban, and the campus size is 168 acres. It utilizes a 4-1-4-based academic calendar. Massachusetts Institute of Technology's ranking in the 2024 edition of Best Colleges is National Universities, #2. Its tuition and fees are $60,156." );
  } else if ((subject == "engineering" && States == "Connecticut")) {
    setText("finalAnswer", userName + " We recommend that you should go to Yale University. Yale University is a private institution that was founded in 1701. It has a total undergraduate enrollment of 6,645 (fall 2022), its setting is city, and the campus size is 373 acres. It utilizes a semester-based academic calendar. Yale University's ranking in the 2024 edition of Best Colleges is National Universities, #5. Its tuition and fees are $64,700.");
  } else if ((subject == "Math" && States == "Michigan")) {
    setText("finalAnswer", userName + " We recommend that you should go to Oakland University. Oakland University is a public institution that was founded in 1957. It has a total undergraduate enrollment of 12,841 (fall 2022), its setting is suburban, and the campus size is 1,444 acres. It utilizes a semester-based academic calendar. Oakland University's ranking in the 2024 edition of Best Colleges is National Universities, #332. Its in-state tuition and fees are $14,694; out-of-state tuition and fees are $23,188.");
  } else if ((subject == "Math" && States == "Massachusetts")) {
    setText("finalAnswer", userName + " We recommend that you should go to Boston University. Boston University is a private institution that was founded in 1839. It has a total undergraduate enrollment of 18,459 (fall 2022), its setting is urban, and the campus size is 140 acres. It utilizes a semester-based academic calendar. Boston University's ranking in the 2024 edition of Best Colleges is National Universities, #43. Its tuition and fees are $65,168." );
  } else if ((subject == "Math" && States == "Connecticut")) {
    setText("finalAnswer", userName + " We recommend that you should go to Central Connecticut State University. Central Connecticut State University is a public institution that was founded in 1849. It has a total undergraduate enrollment of 7,665 (fall 2022), its setting is suburban, and the campus size is 314 acres. It utilizes a semester-based academic calendar. Central Connecticut State University's ranking in the 2024 edition of Best Colleges is Regional Universities North, #69. Its in-state tuition and fees are $12,460; out-of-state tuition and fees are $25,736.");
  } else if ((subject == "Business" && States == "California")) {
    setText("finalAnswer", userName + " We recommend that you should go to California State University, Northridge. California State University—Northridge is a public institution. It has a total undergraduate enrollment of 31,957 (fall 2022), and the campus size is 356 acres. It utilizes a semester-based academic calendar. California State University—Northridge's ranking in the 2024 edition of Best Colleges is Regional Universities West, #25. Its in-state tuition and fees are $7,069; out-of-state tuition and fees are $18,949.");
  } else if ((subject == "Business" && States == "Massachusetts")) {
    setText("finalAnswer", userName + " We recommend that you should go to Northeastern University. Northeastern University is a private institution that was founded in 1898. It has a total undergraduate enrollment of 16,302 (fall 2022), its setting is urban, and the campus size is 73 acres. It utilizes a semester-based academic calendar. Northeastern University's ranking in the 2024 edition of Best Colleges is National Universities, #53. Its tuition and fees are $63,141.");
  } else if ((subject == "Business" && States == "Connecticut")) {
    setText("finalAnswer", userName + " We recommend that you should go to Quinnipiac University. Quinnipiac University is a private institution that was founded in 1929. It has a total undergraduate enrollment of 6,073 (fall 2022), its setting is suburban, and the campus size is 750 acres. It utilizes a semester-based academic calendar. Quinnipiac University's ranking in the 2024 edition of Best Colleges is National Universities, #170. Its tuition and fees are $53,090." );
  } else if ((subject == "technology" && States == "California")) {
    setText("finalAnswer", userName + " We recommend that you should go to California Institute of Technology. California Institute of Technology is a private institution that was founded in 1891. It has a total undergraduate enrollment of 982 (fall 2022), its setting is suburban, and the campus size is 124 acres. It utilizes a quarter-based academic calendar. California Institute of Technology's ranking in the 2024 edition of Best Colleges is National Universities, #7. Its tuition and fees are $63,255. " );
  } else if ((subject == "technology" && States == "Michigan")) {
    setText("finalAnswer", userName + " We recommend that you should go to Davenport University. Davenport University is a private institution that was founded in 1866. It has a total undergraduate enrollment of 4,352 (fall 2022), and the campus size is 77 acres. It utilizes a semester-based academic calendar. Davenport University's ranking in the 2024 edition of Best Colleges is Regional Universities Midwest, #133. Its tuition and fees are $22,244" );
  } else if ((subject == "technology" && States == "Connecticut")) {
    setText("finalAnswer", userName + " We recommend that you should go to Sacred Heart University. Sacred Heart University is a private institution that was founded in 1963. It has a total undergraduate enrollment of 6,782 (fall 2022), its setting is suburban, and the campus size is 350 acres. It utilizes a differs by program-based academic calendar. Sacred Heart University's ranking in the 2024 edition of Best Colleges is National Universities, #209. Its tuition and fees are $48,460.");
  } else if ((subject == "engineering" && States == "California")) {
    setText("finalAnswer", userName + " We recommend that you should go to the University of California, Berkeley. University of California, Berkeley is a public institution that was founded in 1868. It has a total undergraduate enrollment of 32,831 (fall 2022), its setting is city, and the campus size is 1,232 acres. It utilizes a semester-based academic calendar. University of California, Berkeley's ranking in the 2024 edition of Best Colleges is National Universities, #15. Its in-state tuition and fees are $15,891; out-of-state tuition and fees are $48,465." );
  } else if ((subject == "engineering" && States == "Michigan")) {
    setText("finalAnswer", userName + " We recommend that you should go to Kettering University. Kettering University is a private institution that was founded in 1919. It has a total undergraduate enrollment of 1,422 (fall 2022), its setting is urban, and the campus size is 85 acres. It utilizes a semester-based academic calendar. Kettering University's ranking in the 2024 edition of Best Colleges is Regional Universities Midwest, #9. Its tuition and fees are $46,380."  );
  } else if ((subject == "engineering" && States == "Massachusetts")) {
    setText("finalAnswer", userName + " We recommend that you should go to Wentworth Institute of Technology. Wentworth Institute of Technology is a private institution that was founded in 1904. It has a total undergraduate enrollment of 3,713 (fall 2022), its setting is city, and the campus size is 31 acres. It utilizes a semester-based academic calendar. Wentworth Institute of Technology's ranking in the 2024 edition of Best Colleges is Regional Universities North, #33. Its tuition and fees are $41,010."  );
  }
}
